window.reviewData = [
    {
      name: "Arashdeep",
      date: "2023-08-09",
      rating: 5,
      review: "One of the best games I've ever played in my life. I get to spend quality family time with this game!",
    },
    {
      name: "Sukhwinder",
      date: "2023-08-08",
      rating: 2,
      review: "It was not fun playing it alone. I need friends.",
    },
    {
      name: "Sahib",
      date: "2023-08-07",
      rating: 3,
      review:
        "I like playing professionally so I'll have to wait until competition picks up!",
    },
    {
      name: "Narula",
      date: "2023-07-06",
      rating: 2,
      review: "Very difficult to play. ",
    },
    {
      name: "Vajinder",
      date: "2023-06-05",
      rating: 5,
      review: "Very good game gg"
    },
  ];
  